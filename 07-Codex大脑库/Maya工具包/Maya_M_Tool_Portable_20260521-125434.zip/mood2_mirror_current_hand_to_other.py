from __future__ import annotations

import maya.cmds as cmds


SOURCE_DRIVER = "nurbsCircle4"
SOURCE_ROOT = "EW"
TARGET_ROOT = "W"
ATTR = "M"


def _ensure_target_driver() -> str | None:
    # In this scene the opposite wrist control is usually the visible control under W.
    candidates = ["pasted__nurbsCircle2", "nurbsCircle1", "nurbsCircle2", "W", TARGET_ROOT]
    for node in candidates:
        matches = cmds.ls(node, long=True) or []
        for match in matches:
            if cmds.nodeType(match) == "joint":
                continue
            plug = f"{match}.{ATTR}"
            if not cmds.objExists(plug):
                cmds.addAttr(match, ln=ATTR, at="double", min=0, max=5, dv=0, k=True)
            else:
                try:
                    cmds.addAttr(plug, edit=True, min=0, max=5)
                except Exception:
                    pass
            cmds.setAttr(plug, lock=False, keyable=True, channelBox=True)
            return match
    # If only a joint is available, still allow it as a fallback.
    matches = cmds.ls(TARGET_ROOT, long=True) or []
    if matches:
        target = matches[0]
        plug = f"{target}.{ATTR}"
        if not cmds.objExists(plug):
            cmds.addAttr(target, ln=ATTR, at="double", min=0, max=5, dv=0, k=True)
        cmds.setAttr(plug, lock=False, keyable=True, channelBox=True)
        return target
    return None


def _children_joints(root: str) -> list[str]:
    roots = cmds.ls(root, long=True) or []
    if not roots:
        return []
    root_path = roots[0]
    joints: list[str] = []
    if cmds.nodeType(root_path) == "joint":
        joints.append(root_path)
    for child in cmds.listRelatives(root_path, allDescendents=True, fullPath=True) or []:
        if cmds.nodeType(child) == "joint":
            joints.append(child)
    return list(dict.fromkeys(joints))


def _short(node: str) -> str:
    return node.split("|")[-1].split(":")[-1]


def _find_dest_plug(curve: str) -> str | None:
    outs = cmds.listConnections(f"{curve}.output", source=False, destination=True, plugs=True) or []
    for dest in outs:
        if "." in dest:
            return dest
    return None


def _long_node(node: str) -> str | None:
    matches = cmds.ls(node, long=True) or []
    return matches[0] if matches else None


def _curve_keys(curve: str) -> list[tuple[float, float]]:
    xs = cmds.keyframe(curve, query=True, floatChange=True) or []
    ys = cmds.keyframe(curve, query=True, valueChange=True) or []
    return [(float(x), float(y)) for x, y in zip(xs, ys)]


def _delete_incoming_anim(plug: str) -> None:
    sources = cmds.listConnections(plug, source=True, destination=False, plugs=False) or []
    for src in sources:
        if cmds.objExists(src) and cmds.nodeType(src).startswith("animCurve"):
            try:
                cmds.delete(src)
            except Exception:
                pass


def _source_records() -> list[tuple[str, str, list[tuple[float, float]]]]:
    plug = f"{SOURCE_DRIVER}.{ATTR}"
    curves = cmds.listConnections(plug, source=False, destination=True, type="animCurve") or []
    records: list[tuple[str, str, list[tuple[float, float]]]] = []
    for curve in sorted(set(curves)):
        dest = _find_dest_plug(curve)
        if not dest:
            continue
        node, attr = dest.split(".", 1)
        node_long = _long_node(node)
        if not node_long or cmds.nodeType(node_long) != "joint":
            continue
        records.append((node_long, attr, _curve_keys(curve)))
    return records


def mirror(sign: float = -1.0) -> None:
    source_plug = f"{SOURCE_DRIVER}.{ATTR}"
    if not cmds.objExists(source_plug):
        cmds.warning(f"找不到源控制器 {source_plug}")
        return

    source_joints = _children_joints(SOURCE_ROOT)
    target_joints = _children_joints(TARGET_ROOT)
    if not source_joints or not target_joints:
        cmds.warning("找不到 EW/W 两边的 joint 链。")
        return

    target_driver = _ensure_target_driver()
    if not target_driver:
        cmds.warning("找不到另一只手的目标控制器。")
        return
    target_plug = f"{target_driver}.{ATTR}"

    source_index = {j: i for i, j in enumerate(source_joints)}
    source_short_index = {_short(j): i for i, j in enumerate(source_joints)}
    records = _source_records()
    if not records:
        cmds.warning(f"{source_plug} 没有可镜像的 M 驱动。")
        return

    cmds.undoInfo(openChunk=True, chunkName="Codex mirror current hand M")
    try:
        made = 0
        skipped = []
        for source_joint, attr, keys in records:
            idx = source_index.get(source_joint)
            if idx is None:
                idx = source_short_index.get(_short(source_joint))
            if idx is None or idx >= len(target_joints):
                skipped.append(_short(source_joint))
                continue
            target_joint = target_joints[idx]
            target_attr = f"{target_joint}.{attr}"
            if not cmds.objExists(target_attr):
                skipped.append(f"{_short(target_joint)}.{attr}")
                continue

            _delete_incoming_anim(target_attr)
            neutral = float(cmds.getAttr(target_attr))
            source_zero = None
            for x, y in keys:
                if abs(x) < 0.001:
                    source_zero = y
                    break
            if source_zero is None:
                source_zero = keys[0][1] if keys else 0.0

            for x, y in keys:
                value = neutral + (y - source_zero) * sign
                cmds.setAttr(target_plug, x)
                cmds.setAttr(target_attr, value)
                cmds.setDrivenKeyframe(target_attr, cd=target_plug)
            cmds.setAttr(target_attr, neutral)
            made += 1

        cmds.setAttr(target_plug, 0)
        cmds.select(target_driver, replace=True)
        print(f"完成：镜像 {made} 条驱动到 {target_driver}.{ATTR}")
        if skipped:
            print("跳过:", ", ".join(skipped))
        print("测试目标 M=5。如果方向错了，Ctrl+Z 后运行 mirror(1.0)。")
    finally:
        cmds.undoInfo(closeChunk=True)


mirror(-1.0)
