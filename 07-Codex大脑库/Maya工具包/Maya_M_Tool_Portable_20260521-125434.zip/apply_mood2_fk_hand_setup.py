from __future__ import annotations

import argparse
import os
import sys


def _norm(path: str) -> str:
    return os.path.abspath(os.path.expanduser(path))


def _init_maya():
    try:
        import maya.standalone  # type: ignore

        maya.standalone.initialize(name="python")
    except Exception as exc:
        message = str(exc)
        if "Already initialized" not in message:
            raise

    import maya.cmds as cmds  # type: ignore

    return cmds


def _exists(cmds, node: str) -> bool:
    return bool(cmds.objExists(node))


def _unlock_attr(cmds, plug: str) -> None:
    if cmds.objExists(plug):
        try:
            cmds.setAttr(plug, lock=False)
        except Exception:
            pass


def _lock_channels(cmds, node: str, keep_rotate: bool = True) -> None:
    if not _exists(cmds, node):
        return
    lock_attrs = ["tx", "ty", "tz", "sx", "sy", "sz", "v"]
    if not keep_rotate:
        lock_attrs += ["rx", "ry", "rz"]
    for attr in lock_attrs:
        plug = f"{node}.{attr}"
        if cmds.objExists(plug):
            try:
                cmds.setAttr(plug, lock=True, keyable=False, channelBox=False)
            except Exception:
                pass
    for attr in ["rx", "ry", "rz"]:
        plug = f"{node}.{attr}"
        if cmds.objExists(plug):
            try:
                cmds.setAttr(plug, lock=False, keyable=True, channelBox=True)
            except Exception:
                pass


def _add_float_attr(cmds, node: str, attr: str, default: float, minimum: float, maximum: float) -> None:
    if not _exists(cmds, node):
        return
    plug = f"{node}.{attr}"
    if not cmds.objExists(plug):
        cmds.addAttr(node, ln=attr, at="double", min=minimum, max=maximum, dv=default, k=True)
    else:
        _unlock_attr(cmds, plug)
        try:
            cmds.addAttr(plug, edit=True, min=minimum, max=maximum)
        except Exception:
            pass
        cmds.setAttr(plug, default)
    cmds.setAttr(plug, keyable=True, channelBox=True)


def _set_rotate_limits(cmds, node: str, xyz_limit: float = 90.0) -> None:
    if not _exists(cmds, node):
        return
    try:
        cmds.transformLimits(
            node,
            rx=(-xyz_limit, xyz_limit),
            ry=(-xyz_limit, xyz_limit),
            rz=(-xyz_limit, xyz_limit),
            erx=(True, True),
            ery=(True, True),
            erz=(True, True),
        )
    except Exception:
        pass


def _safe_set(cmds, plug: str, value: float) -> None:
    if not cmds.objExists(plug):
        return
    try:
        cmds.setAttr(plug, lock=False)
        cmds.setAttr(plug, value)
    except Exception:
        pass


def _driven_curl(cmds, driver: str, attr: str, driven: list[tuple[str, str, float]]) -> None:
    if not cmds.objExists(f"{driver}.{attr}"):
        return

    neutral: dict[tuple[str, str], float] = {}
    for joint, rotate_attr, _amount in driven:
        plug = f"{joint}.{rotate_attr}"
        if not cmds.objExists(plug):
            continue
        try:
            neutral[(joint, rotate_attr)] = float(cmds.getAttr(plug))
        except Exception:
            pass

    poses = [
        (-5.0, -1.0),
        (0.0, 0.0),
        (5.0, 1.0),
    ]
    for driver_value, sign in poses:
        cmds.setAttr(f"{driver}.{attr}", driver_value)
        for joint, rotate_attr, amount in driven:
            plug = f"{joint}.{rotate_attr}"
            if not cmds.objExists(plug):
                continue
            base = neutral.get((joint, rotate_attr), 0.0)
            _safe_set(cmds, plug, base + amount * sign)
            try:
                cmds.setDrivenKeyframe(plug, cd=f"{driver}.{attr}")
            except Exception:
                pass

    cmds.setAttr(f"{driver}.{attr}", 0.0)
    for joint, rotate_attr, _amount in driven:
        base = neutral.get((joint, rotate_attr))
        if base is not None:
            _safe_set(cmds, f"{joint}.{rotate_attr}", base)


def _add_note(cmds) -> None:
    node = "codex_fk_hand_setup_NOTE"
    if not cmds.objExists(node):
        node = cmds.createNode("network", name=node)
    if not cmds.objExists(f"{node}.note"):
        cmds.addAttr(node, ln="note", dt="string")
    text = (
        "Codex added a safe FK hand-control pass based on the reference video: "
        "locked non-rotation channels, added wrist M attributes with -5..5 limits, "
        "and set driven keys relative to each joint's original neutral rotation. "
        "Original desktop file was not overwritten."
    )
    cmds.setAttr(f"{node}.note", text, type="string")


def apply_setup(source: str, output: str) -> None:
    cmds = _init_maya()

    source = _norm(source)
    output = _norm(output)
    if not os.path.exists(source):
        raise FileNotFoundError(source)

    cmds.file(source, open=True, force=True, ignoreVersion=True, prompt=False)

    control_nodes = [
        "pasted__nurbsCircle3",
        "nurbsCircle1",
        "nurbsCircle2",
        "nurbsCircle3",
        "nurbsCircle4",
        "nurbsCircle5",
        "nurbsCircle6",
        "nurbsCircle7",
        "e",
        "eq",
        "ew",
        "e1",
        "eq1",
        "ew1",
    ]
    for node in control_nodes:
        _lock_channels(cmds, node, keep_rotate=True)
        _set_rotate_limits(cmds, node, 90.0)

    # The video uses a wrist-control custom attribute named M. These are the
    # closest existing wrist controls in this file based on the constraints.
    left_driver = "nurbsCircle4"
    right_driver = "ew1"
    for driver in [left_driver, right_driver]:
        _add_float_attr(cmds, driver, "M", 0.0, -5.0, 5.0)
        _add_float_attr(cmds, driver, "curl", 0.0, -10.0, 10.0)

    left_driven = [
        ("joint7", "ry", 18.0),
        ("joint8", "ry", 28.0),
        ("joint10", "ry", 42.0),
    ]
    right_driven = [
        ("pasted__joint9", "ry", -18.0),
        ("pasted__joint10", "ry", -28.0),
        ("pasted__joint18", "ry", -42.0),
    ]
    _driven_curl(cmds, left_driver, "M", left_driven)
    _driven_curl(cmds, right_driver, "M", right_driven)

    _add_note(cmds)

    out_dir = os.path.dirname(output)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    cmds.file(rename=output)
    cmds.file(save=True, type="mayaAscii", force=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="Apply a safe FK hand-control setup to mood2.ma.")
    parser.add_argument("--source", default=r"C:\Users\19308\Desktop\mood2.ma")
    parser.add_argument("--output", default=r"C:\Users\19308\Desktop\mood2_codex_fk_safe.ma")
    args = parser.parse_args()

    apply_setup(args.source, args.output)
    print(f"Wrote: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
