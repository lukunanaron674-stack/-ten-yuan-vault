from __future__ import annotations

import maya.cmds as cmds


ATTR = "M"


def clean_wrong_mirror() -> None:
    """Remove recent/incorrect M-driven curves outside the working hand driver."""
    cmds.undoInfo(openChunk=True, chunkName="Codex clean wrong M mirror")
    try:
        deleted = 0
        m_nodes = []
        for node in cmds.ls(long=True) or []:
            if cmds.objExists(f"{node}.{ATTR}"):
                m_nodes.append(node)

        # Keep the source controller. Remove extra target/controller M attributes and
        # their driven curves; this is meant as a cleanup after a bad auto mirror.
        for node in m_nodes:
            short = node.split("|")[-1]
            if short == "nurbsCircle4":
                continue
            plug = f"{node}.{ATTR}"
            curves = cmds.listConnections(plug, source=False, destination=True, type="animCurve") or []
            for curve in sorted(set(curves)):
                if cmds.objExists(curve):
                    cmds.delete(curve)
                    deleted += 1
            try:
                cmds.deleteAttr(plug)
            except Exception:
                pass

        if cmds.objExists("nurbsCircle4.M"):
            cmds.setAttr("nurbsCircle4.M", 0)
            cmds.select("nurbsCircle4", replace=True)

        print(f"清理完成：删除错误镜像 M 曲线 {deleted} 条。保留 nurbsCircle4.M。")
    finally:
        cmds.undoInfo(closeChunk=True)


clean_wrong_mirror()
