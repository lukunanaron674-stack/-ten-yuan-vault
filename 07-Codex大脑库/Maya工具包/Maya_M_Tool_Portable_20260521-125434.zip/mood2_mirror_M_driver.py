from __future__ import annotations

import maya.cmds as cmds


ATTR = "M"
WIN = "codex_mood2_mirror_m_driver"
STATE = {"source": "", "target": ""}


def _has_m(node: str) -> bool:
    return bool(node and cmds.objExists(f"{node}.{ATTR}"))


def _ensure_m(node: str) -> None:
    plug = f"{node}.{ATTR}"
    if not cmds.objExists(plug):
        cmds.addAttr(node, ln=ATTR, at="double", min=0, max=5, dv=0, k=True)
    else:
        try:
            cmds.addAttr(plug, edit=True, min=0, max=5)
        except Exception:
            pass
    cmds.setAttr(plug, lock=False, keyable=True, channelBox=True)


def _selected_node() -> str | None:
    sel = cmds.ls(selection=True, long=False) or []
    return sel[0] if sel else None


def _load_source(*_args) -> None:
    node = _selected_node()
    if not node or not _has_m(node):
        cmds.warning("请先选已经做好 M 的手腕控制器。")
        return
    STATE["source"] = node
    _refresh_labels()
    print(f"源控制器: {node}.{ATTR}")


def _load_target(*_args) -> None:
    node = _selected_node()
    if not node:
        cmds.warning("请先选另一只手的手腕控制器。")
        return
    if cmds.nodeType(node) == "joint":
        cmds.warning("目标应该是控制圈/控制器，不要选 joint。")
        return
    _ensure_m(node)
    STATE["target"] = node
    _refresh_labels()
    print(f"目标控制器: {node}.{ATTR}")


def _map_joint(name: str) -> str | None:
    candidates: list[str] = []
    if name.startswith("pasted__joint"):
        candidates.append(name.replace("pasted__", "", 1))
    elif name.startswith("joint"):
        candidates.append("pasted__" + name)

    # Fallback: common mirrored pasted hand branch in this scene.
    if name.startswith("pasted__joint"):
        number = name.replace("pasted__joint", "")
        if number.isdigit():
            n = int(number)
            if 9 <= n <= 24:
                candidates.append(f"joint{n}")

    for candidate in candidates:
        if cmds.objExists(candidate):
            return candidate
    return None


def _curve_keys(curve: str) -> list[tuple[float, float]]:
    xs = cmds.keyframe(curve, query=True, floatChange=True) or []
    ys = cmds.keyframe(curve, query=True, valueChange=True) or []
    return [(float(x), float(y)) for x, y in zip(xs, ys)]


def _neutral_value(keys: list[tuple[float, float]]) -> float:
    for x, y in keys:
        if abs(x) < 0.001:
            return y
    if keys:
        return min(keys, key=lambda pair: abs(pair[0]))[1]
    return 0.0


def _delete_existing_driver_curve(target_plug: str) -> None:
    sources = cmds.listConnections(target_plug, source=True, destination=False, plugs=False) or []
    for src in sources:
        if cmds.nodeType(src).startswith("animCurve"):
            try:
                cmds.delete(src)
            except Exception:
                pass


def _driven_destinations(source: str) -> list[tuple[str, str, list[tuple[float, float]]]]:
    plug = f"{source}.{ATTR}"
    curves = cmds.listConnections(plug, source=False, destination=True, type="animCurve") or []
    result: list[tuple[str, str, list[tuple[float, float]]]] = []
    for curve in sorted(set(curves)):
        outs = cmds.listConnections(f"{curve}.output", source=False, destination=True, plugs=True) or []
        for dest in outs:
            if "." not in dest:
                continue
            node, attr = dest.split(".", 1)
            if cmds.nodeType(node) != "joint":
                continue
            keys = _curve_keys(curve)
            if keys:
                result.append((node, attr, keys))
    return result


def _mirror(sign: float) -> None:
    source = STATE["source"]
    target = STATE["target"]
    if not _has_m(source):
        cmds.warning("先加载源控制器。")
        return
    if not target:
        cmds.warning("先加载目标控制器。")
        return
    _ensure_m(target)

    records = _driven_destinations(source)
    if not records:
        cmds.warning(f"{source}.{ATTR} 没有找到手指驱动曲线。")
        return

    cmds.undoInfo(openChunk=True, chunkName="Codex mirror M driver")
    try:
        cmds.setAttr(f"{target}.{ATTR}", 0)
        created = 0
        skipped: list[str] = []
        for source_joint, attr, keys in records:
            target_joint = _map_joint(source_joint)
            if not target_joint:
                skipped.append(source_joint)
                continue
            target_plug = f"{target_joint}.{attr}"
            if not cmds.objExists(target_plug):
                skipped.append(f"{target_joint}.{attr}")
                continue

            source_neutral = _neutral_value(keys)
            try:
                target_neutral = float(cmds.getAttr(target_plug))
            except Exception:
                target_neutral = 0.0

            _delete_existing_driver_curve(target_plug)
            for x, y in keys:
                # Keep 0 as the target hand's own neutral pose; mirror the delta.
                value = target_neutral + (y - source_neutral) * sign
                cmds.setAttr(f"{target}.{ATTR}", x)
                cmds.setAttr(target_plug, value)
                cmds.setDrivenKeyframe(target_plug, cd=f"{target}.{ATTR}")

            cmds.setAttr(f"{target}.{ATTR}", 0)
            cmds.setAttr(target_plug, target_neutral)
            created += 1

        cmds.select(target, replace=True)
        print(f"完成：镜像 {created} 条 M 驱动到 {target}.{ATTR}")
        if skipped:
            print("跳过：", ", ".join(skipped))
        print("现在测试目标控制器 M=0 / 5。如果方向反了，Ctrl+Z 后点另一个镜像按钮。")
    finally:
        cmds.undoInfo(closeChunk=True)


def _refresh_labels() -> None:
    if cmds.window(WIN, exists=True):
        cmds.text("codex_mirror_source_label", edit=True, label=f"源: {STATE['source'] or '未加载'}")
        cmds.text("codex_mirror_target_label", edit=True, label=f"目标: {STATE['target'] or '未加载'}")


def show_ui() -> None:
    if cmds.window(WIN, exists=True):
        cmds.deleteUI(WIN)
    cmds.window(WIN, title="Codex 镜像 M 手指驱动", sizeable=False)
    cmds.columnLayout(adjustableColumn=True, rowSpacing=8, columnAttach=("both", 8))
    cmds.text(label="1. 选做好 M 的手腕控制器，加载源\n2. 选另一只手腕控制器，加载目标\n3. 先试同向，错了 Ctrl+Z 再试反向")
    cmds.text("codex_mirror_source_label", label="源: 未加载")
    cmds.button(label="加载当前选择为源 M 控制器", command=_load_source)
    cmds.text("codex_mirror_target_label", label="目标: 未加载")
    cmds.button(label="加载当前选择为目标手腕控制器", command=_load_target)
    cmds.separator(height=8, style="in")
    cmds.button(label="镜像到另一只手：同向", command=lambda *_: _mirror(1.0))
    cmds.button(label="镜像到另一只手：反向", command=lambda *_: _mirror(-1.0))
    cmds.showWindow(WIN)
    _refresh_labels()


show_ui()
