from __future__ import annotations

import maya.cmds as cmds


DRIVER = "nurbsCircle4"
DRIVER_ATTR = "M"


def _ensure_driver_attr():
    if not cmds.objExists(DRIVER):
        cmds.warning("找不到控制器 nurbsCircle4。请先打开 mood2_codex_attrs_only.ma。")
        return False
    plug = f"{DRIVER}.{DRIVER_ATTR}"
    if not cmds.objExists(plug):
        cmds.addAttr(DRIVER, ln=DRIVER_ATTR, at="double", min=-5, max=5, dv=0, k=True)
    cmds.setAttr(plug, keyable=True, channelBox=True)
    return True


def _selected_joint():
    sel = cmds.ls(selection=True, long=False) or []
    if not sel:
        cmds.warning("先选一个手指关节，比如 pasted__joint10 / pasted__joint17。")
        return None
    node = sel[0]
    if cmds.nodeType(node) != "joint":
        cmds.warning("当前选择不是 joint。请在大纲里点紫色骨骼节点。")
        return None
    return node


def connect_selected(axis="ry", amount=35.0):
    """Connect selected joint rotation to nurbsCircle4.M using set driven keys."""
    if not _ensure_driver_attr():
        return
    joint = _selected_joint()
    if not joint:
        return
    plug = f"{joint}.{axis}"
    if not cmds.objExists(plug):
        cmds.warning(f"{joint} 没有 {axis} 属性。")
        return

    cmds.undoInfo(openChunk=True, chunkName="Codex connect selected joint to M")
    try:
        base = cmds.getAttr(plug)
        cmds.setAttr(f"{DRIVER}.{DRIVER_ATTR}", 0)
        cmds.setAttr(plug, base)
        cmds.setDrivenKeyframe(plug, cd=f"{DRIVER}.{DRIVER_ATTR}")

        cmds.setAttr(f"{DRIVER}.{DRIVER_ATTR}", 5)
        cmds.setAttr(plug, base + amount)
        cmds.setDrivenKeyframe(plug, cd=f"{DRIVER}.{DRIVER_ATTR}")

        cmds.setAttr(f"{DRIVER}.{DRIVER_ATTR}", -5)
        cmds.setAttr(plug, base - amount)
        cmds.setDrivenKeyframe(plug, cd=f"{DRIVER}.{DRIVER_ATTR}")

        cmds.setAttr(f"{DRIVER}.{DRIVER_ATTR}", 0)
        cmds.setAttr(plug, base)
        cmds.select(DRIVER, replace=True)
        print(f"已连接: {DRIVER}.{DRIVER_ATTR} -> {joint}.{axis}, 幅度 {amount}")
    finally:
        cmds.undoInfo(closeChunk=True)


def reset_driver():
    if cmds.objExists(f"{DRIVER}.{DRIVER_ATTR}"):
        cmds.setAttr(f"{DRIVER}.{DRIVER_ATTR}", 0)
    cmds.select(DRIVER, replace=True)


def show_ui():
    win = "codex_mood2_joint_driver_tool"
    if cmds.window(win, exists=True):
        cmds.deleteUI(win)
    cmds.window(win, title="Codex 手指 M 驱动测试", sizeable=False)
    cmds.columnLayout(adjustableColumn=True, rowSpacing=8, columnAttach=("both", 8))
    cmds.text(label="1. 先在大纲里选一个手指 joint\n2. 点一个轴测试\n3. 不对就 Ctrl+Z 撤销，换轴/换幅度")
    cmds.separator(height=8, style="in")
    cmds.button(label="接当前 joint：rotateY 35", command=lambda *_: connect_selected("ry", 35.0))
    cmds.button(label="接当前 joint：rotateY -35", command=lambda *_: connect_selected("ry", -35.0))
    cmds.button(label="接当前 joint：rotateX 35", command=lambda *_: connect_selected("rx", 35.0))
    cmds.button(label="接当前 joint：rotateX -35", command=lambda *_: connect_selected("rx", -35.0))
    cmds.button(label="接当前 joint：rotateZ 35", command=lambda *_: connect_selected("rz", 35.0))
    cmds.button(label="接当前 joint：rotateZ -35", command=lambda *_: connect_selected("rz", -35.0))
    cmds.separator(height=8, style="in")
    cmds.button(label="M 归零并选中控制器", command=lambda *_: reset_driver())
    cmds.showWindow(win)


show_ui()
