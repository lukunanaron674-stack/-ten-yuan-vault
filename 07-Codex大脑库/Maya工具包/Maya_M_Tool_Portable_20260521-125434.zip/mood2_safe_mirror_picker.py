from __future__ import annotations

import maya.cmds as cmds


ATTR = "M"
WIN = "codex_mood2_safe_mirror_picker"
STATE = {
    "source_driver": "",
    "target_driver": "",
    "target_root": "",
}


def _short(node: str) -> str:
    return node.split("|")[-1].split(":")[-1]


def _long(node: str) -> str | None:
    matches = cmds.ls(node, long=True) or []
    return matches[0] if matches else None


def _selection_one() -> str | None:
    sel = cmds.ls(selection=True, long=True) or []
    if not sel:
        return None
    return sel[-1]


def _ensure_m(node: str) -> str:
    plug = f"{node}.{ATTR}"
    if not cmds.objExists(plug):
        cmds.addAttr(node, ln=ATTR, at="double", min=0, max=5, dv=0, k=True)
    else:
        try:
            cmds.addAttr(plug, edit=True, min=0, max=5)
        except Exception:
            pass
    cmds.setAttr(plug, lock=False, keyable=True, channelBox=True)
    return plug


def _load_source_driver(*_args) -> None:
    node = _selection_one()
    if not node:
        cmds.warning("先选已经做好 M 的手腕控制圈。")
        return
    if not cmds.objExists(f"{node}.{ATTR}"):
        cmds.warning("这个对象没有 M。请选已经能控制拳头的手腕圈。")
        return
    STATE["source_driver"] = node
    _refresh()
    print("源 M 控制器:", node)


def _load_target_driver(*_args) -> None:
    node = _selection_one()
    if not node:
        cmds.warning("先选另一只手的手腕控制圈。")
        return
    STATE["target_driver"] = node
    _ensure_m(node)
    _refresh()
    print("目标 M 控制器:", node)


def _load_target_root(*_args) -> None:
    node = _selection_one()
    if not node:
        cmds.warning("先选另一只手的手腕根 joint。")
        return
    if cmds.nodeType(node) != "joint":
        cmds.warning("目标根要选 joint，不是控制圈。比如另一只手掌/手腕下面那颗紫色骨骼。")
        return
    STATE["target_root"] = node
    _refresh()
    print("目标手 root joint:", node)


def _source_records() -> list[tuple[str, str, list[tuple[float, float]]]]:
    source_driver = STATE["source_driver"]
    if not source_driver:
        return []
    plug = f"{source_driver}.{ATTR}"
    curves = cmds.listConnections(plug, source=False, destination=True, type="animCurve") or []
    records: list[tuple[str, str, list[tuple[float, float]]]] = []
    for curve in sorted(set(curves)):
        outs = cmds.listConnections(f"{curve}.output", source=False, destination=True, plugs=True) or []
        for dest in outs:
            if "." not in dest:
                continue
            node, attr = dest.split(".", 1)
            node_long = _long(node)
            if not node_long or cmds.nodeType(node_long) != "joint":
                continue
            xs = cmds.keyframe(curve, query=True, floatChange=True) or []
            ys = cmds.keyframe(curve, query=True, valueChange=True) or []
            keys = [(float(x), float(y)) for x, y in zip(xs, ys)]
            if keys:
                records.append((node_long, attr, keys))
    return records


def _target_joints() -> list[str]:
    root = STATE["target_root"]
    if not root:
        return []
    joints: list[str] = [root]
    joints.extend(cmds.listRelatives(root, allDescendents=True, fullPath=True, type="joint") or [])
    return list(dict.fromkeys(joints))


def _delete_incoming_anim(plug: str) -> None:
    sources = cmds.listConnections(plug, source=True, destination=False, plugs=False) or []
    for src in sources:
        if cmds.objExists(src) and cmds.nodeType(src).startswith("animCurve"):
            try:
                cmds.delete(src)
            except Exception:
                pass


def _zero_value(keys: list[tuple[float, float]]) -> float:
    for x, y in keys:
        if abs(x) < 0.001:
            return y
    return keys[0][1] if keys else 0.0


def _mirror(sign: float) -> None:
    if not STATE["source_driver"]:
        cmds.warning("先加载源 M 控制器。")
        return
    if not STATE["target_driver"]:
        cmds.warning("先加载目标 M 控制器。")
        return
    if not STATE["target_root"]:
        cmds.warning("先加载目标手 root joint。")
        return

    records = _source_records()
    targets = _target_joints()
    if not records:
        cmds.warning("源 M 没有找到驱动曲线。")
        return
    if not targets:
        cmds.warning("目标 root 下面没有找到 joints。")
        return

    target_plug = _ensure_m(STATE["target_driver"])

    cmds.undoInfo(openChunk=True, chunkName="Codex safe mirror selected M")
    try:
        made = 0
        skipped: list[str] = []
        for index, (_src_joint, attr, keys) in enumerate(records):
            if index >= len(targets):
                skipped.append(f"index{index}")
                continue
            target_joint = targets[index]
            plug = f"{target_joint}.{attr}"
            if not cmds.objExists(plug):
                skipped.append(f"{_short(target_joint)}.{attr}")
                continue
            _delete_incoming_anim(plug)
            target_zero = float(cmds.getAttr(plug))
            source_zero = _zero_value(keys)
            for x, y in keys:
                value = target_zero + (y - source_zero) * sign
                cmds.setAttr(target_plug, x)
                cmds.setAttr(plug, value)
                cmds.setDrivenKeyframe(plug, cd=target_plug)
            cmds.setAttr(plug, target_zero)
            made += 1
        cmds.setAttr(target_plug, 0)
        cmds.select(STATE["target_driver"], replace=True)
        print(f"完成：镜像 {made} 条驱动到 {_short(STATE['target_driver'])}.M")
        if skipped:
            print("跳过:", ", ".join(skipped))
        print("现在测试目标 M=5。方向错就 Ctrl+Z，再点另一个方向。")
    finally:
        cmds.undoInfo(closeChunk=True)


def _refresh() -> None:
    if not cmds.window(WIN, exists=True):
        return
    cmds.text("safe_mirror_source_label", edit=True, label=f"源控制器: {_short(STATE['source_driver']) if STATE['source_driver'] else '未加载'}")
    cmds.text("safe_mirror_target_label", edit=True, label=f"目标控制器: {_short(STATE['target_driver']) if STATE['target_driver'] else '未加载'}")
    cmds.text("safe_mirror_root_label", edit=True, label=f"目标root: {_short(STATE['target_root']) if STATE['target_root'] else '未加载'}")


def show_ui() -> None:
    if cmds.window(WIN, exists=True):
        cmds.deleteUI(WIN)
    cmds.window(WIN, title="Codex 安全镜像 M", sizeable=False)
    cmds.columnLayout(adjustableColumn=True, rowSpacing=8, columnAttach=("both", 8))
    cmds.text(label="不要用旧镜像。按按钮逐个加载，错了 Ctrl+Z。")
    cmds.text("safe_mirror_source_label", label="源控制器: 未加载")
    cmds.button(label="1 加载当前选择为源 M 控制器", command=_load_source_driver)
    cmds.text("safe_mirror_target_label", label="目标控制器: 未加载")
    cmds.button(label="2 加载当前选择为目标 M 控制器", command=_load_target_driver)
    cmds.text("safe_mirror_root_label", label="目标root: 未加载")
    cmds.button(label="3 加载当前选择为目标手 root joint", command=_load_target_root)
    cmds.separator(height=8, style="in")
    cmds.button(label="4 镜像：反向", command=lambda *_: _mirror(-1.0))
    cmds.button(label="4 镜像：同向", command=lambda *_: _mirror(1.0))
    cmds.showWindow(WIN)
    _refresh()


show_ui()
