from __future__ import annotations

import os
import runpy


here = os.path.dirname(os.path.abspath(__file__))
runpy.run_path(os.path.join(here, "mood2_M_hand_tool.py"))
