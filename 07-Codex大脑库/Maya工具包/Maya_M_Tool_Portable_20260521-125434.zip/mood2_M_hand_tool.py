from __future__ import annotations

import maya.cmds as cmds


# Unified M hand tool for mood2.ma.
# Merges the old one-click fist script and the manual capture script.
# Safety rule: only touch rotate drivers on the joints you loaded.

ATTR = "M"
DEFAULT_DRIVER = "nurbsCircle4"
MAX_M = 5.0
ROTATE_ATTRS = ("rx", "ry", "rz")

WIN = "codex_mood2_m_hand_tool"
OLD_WINDOWS = (
    "codex_mood2_capture_pose_to_m",
    "codex_mood2_joint_driver_tool",
    "codex_mood2_safe_mirror_picker",
)

FALLBACK_ROOTS = (
    "EW",
    "ew",
    "|Q|QW|QE|W|E|EQ|EW",
)

STATE = {"driver": "", "joints": []}


def _short(node):
    return (node or "").split("|")[-1].split(":")[-1]


def _long(node):
    matches = cmds.ls(node, long=True) or []
    return matches[0] if matches else None


def _exists(node):
    return bool(node and cmds.objExists(node))


def _has_attr(node, attr):
    return bool(_exists(node) and cmds.objExists("%s.%s" % (node, attr)))


def _plug(node, attr):
    return "%s.%s" % (node, attr)


def _driver_plug():
    return _plug(STATE["driver"], ATTR)


def _resolve_driver():
    if _exists(STATE["driver"]):
        return STATE["driver"]

    selected = cmds.ls(selection=True, long=True) or []
    for node in selected:
        if _has_attr(node, ATTR):
            STATE["driver"] = node
            return node

    default = _long(DEFAULT_DRIVER)
    if default:
        STATE["driver"] = default
        return default

    return ""


def _ensure_driver():
    driver = _resolve_driver()
    if not driver:
        cmds.warning("找不到 M 控制器。请先选手腕/手掌控制圈，再点加载 M 控制器。")
        return False

    plug = _plug(driver, ATTR)
    if not cmds.objExists(plug):
        cmds.addAttr(driver, ln=ATTR, at="double", min=0, max=MAX_M, dv=0, k=True)
    else:
        try:
            cmds.addAttr(plug, edit=True, min=0, max=MAX_M)
        except Exception:
            pass

    try:
        cmds.setAttr(plug, lock=False, keyable=True, channelBox=True)
    except Exception:
        pass

    STATE["driver"] = driver
    return True


def _descendant_joints(node):
    joints = []
    if _exists(node) and cmds.nodeType(node) == "joint":
        joints.append(node)

    for child in cmds.listRelatives(node, allDescendents=True, fullPath=True) or []:
        if _exists(child) and cmds.nodeType(child) == "joint":
            joints.append(child)

    return joints


def _selected_joints():
    joints = []
    for node in cmds.ls(selection=True, long=True) or []:
        joints.extend(_descendant_joints(node))
    return list(dict.fromkeys(joints))


def _fallback_joints():
    for root in FALLBACK_ROOTS:
        root_long = _long(root)
        if root_long:
            joints = _descendant_joints(root_long)
            if joints:
                return joints
    return []


def _target_joints(allow_selection=True):
    live = [joint for joint in STATE["joints"] if _exists(joint)]
    if live:
        STATE["joints"] = live
        return live

    if allow_selection:
        selected = _selected_joints()
        if selected:
            STATE["joints"] = selected
            return selected

    return []


def _unlock_rotation(plug):
    try:
        cmds.setAttr(plug, lock=False, keyable=True, channelBox=True)
    except Exception:
        pass


def _capture_pose(joints):
    pose = {}
    for joint in joints:
        if not _exists(joint):
            continue
        for attr in ROTATE_ATTRS:
            plug = _plug(joint, attr)
            if not cmds.objExists(plug):
                continue
            try:
                pose[(joint, attr)] = float(cmds.getAttr(plug))
            except Exception:
                pass
    return pose


def _delete_incoming_anim_curves_for_plug(plug):
    deleted = 0
    sources = cmds.listConnections(plug, source=True, destination=False, plugs=False) or []
    for source in sorted(set(sources)):
        if _exists(source) and cmds.nodeType(source).startswith("animCurve"):
            try:
                cmds.delete(source)
                deleted += 1
            except Exception as exc:
                cmds.warning("删除旧驱动失败 %s: %s" % (source, exc))
    return deleted


def _clear_m_drivers_for_joints(joints):
    deleted = 0
    for joint in joints:
        for attr in ROTATE_ATTRS:
            plug = _plug(joint, attr)
            if cmds.objExists(plug):
                deleted += _delete_incoming_anim_curves_for_plug(plug)
                _unlock_rotation(plug)
    return deleted


def _set_rotate(joint, attr, value):
    plug = _plug(joint, attr)
    if not cmds.objExists(plug):
        return False
    _unlock_rotation(plug)
    try:
        cmds.setAttr(plug, value)
        return True
    except Exception as exc:
        cmds.warning("设置 %s 失败: %s" % (plug, exc))
        return False


def _key_pose(driver_plug, joints, pose, value):
    cmds.setAttr(driver_plug, value)
    keyed = 0
    for joint in joints:
        for attr in ROTATE_ATTRS:
            if (joint, attr) not in pose:
                continue
            plug = _plug(joint, attr)
            if not cmds.objExists(plug):
                continue
            _unlock_rotation(plug)
            try:
                cmds.setAttr(plug, pose[(joint, attr)])
                cmds.setDrivenKeyframe(plug, cd=driver_plug)
                keyed += 1
            except Exception as exc:
                cmds.warning("记录 %s 到 M=%s 失败: %s" % (plug, value, exc))
    return keyed


def _zero_pose(joints):
    pose = {}
    for joint in joints:
        for attr in ROTATE_ATTRS:
            plug = _plug(joint, attr)
            if cmds.objExists(plug):
                pose[(joint, attr)] = 0.0
    return pose


def _refresh():
    if not cmds.window(WIN, exists=True):
        return
    driver = _resolve_driver()
    driver_text = _short(driver) if driver else "未加载"
    cmds.text("codex_m_driver_label", edit=True, label="M 控制器: %s" % driver_text)
    cmds.text("codex_m_joints_label", edit=True, label="关节数: %d" % len(_target_joints(False)))


def load_driver(*_args):
    selected = cmds.ls(selection=True, long=True) or []
    if not selected:
        cmds.warning("先选手腕/手掌控制圈，再点加载。")
        return

    node = selected[0]
    if cmds.nodeType(node) == "joint":
        cmds.warning("M 控制器不要选 joint。请选择手腕/手掌附近的控制圈。")
        return

    STATE["driver"] = node
    if _ensure_driver():
        cmds.select(node, replace=True)
        print("已加载 M 控制器: %s" % _short(node))
    _refresh()


def load_selected_joints(*_args):
    joints = _selected_joints()
    if not joints:
        cmds.warning("先在大纲里选择手指 root joint，或多选手指 joints。")
        return
    STATE["joints"] = joints
    cmds.select(joints, replace=True)
    print("已加载手指 joints: %d 个" % len(joints))
    _refresh()


def auto_load_fallback_joints(*_args):
    joints = _fallback_joints()
    if not joints:
        cmds.warning("没有找到 EW/ew 这样的手指 root。请手动选 root joint 后点加载。")
        return
    STATE["joints"] = joints
    cmds.select(joints, replace=True)
    print("已自动加载手指 joints: %d 个" % len(joints))
    _refresh()


def scan_scene_joints(*_args):
    joints = cmds.ls(type="joint", long=True) or []
    if not joints:
        cmds.warning("全场景没有 joint。")
        return
    STATE["joints"] = list(dict.fromkeys(joints))
    cmds.select(STATE["joints"], replace=True)
    print("已兜底加载全场景 joints: %d 个。只在小练习文件里用这个。" % len(STATE["joints"]))
    _refresh()


def set_m(value, *_args):
    if not _ensure_driver():
        return
    cmds.setAttr(_driver_plug(), float(value))
    cmds.select(STATE["driver"], replace=True)
    print("%s = %s" % (_driver_plug(), value))


def clear_loaded_drivers(*_args):
    if not _ensure_driver():
        return
    joints = _target_joints()
    if not joints:
        cmds.warning("先加载要处理的手指 joints。")
        return

    cmds.undoInfo(openChunk=True, chunkName="Codex clear loaded M drivers")
    try:
        deleted = _clear_m_drivers_for_joints(joints)
        cmds.setAttr(_driver_plug(), 0)
        cmds.select(joints, replace=True)
        print("已清空当前加载关节上的旧 M 驱动: %d 条。" % deleted)
    finally:
        cmds.undoInfo(closeChunk=True)


def straighten_loaded_joints(*_args):
    joints = _target_joints()
    if not joints:
        cmds.warning("先加载或选择要伸直的手指 joints。")
        return

    cmds.undoInfo(openChunk=True, chunkName="Codex straighten loaded joints")
    try:
        changed = 0
        for joint in joints:
            for attr in ROTATE_ATTRS:
                if _set_rotate(joint, attr, 0.0):
                    changed += 1
        cmds.select(joints, replace=True)
        print("已把当前加载 joints 的旋转归零: %d 个通道。" % changed)
    finally:
        cmds.undoInfo(closeChunk=True)


def record_current_pose(value, *_args):
    if not _ensure_driver():
        return
    joints = _target_joints()
    if not joints:
        cmds.warning("先加载手指 joints，或当前选中一些 joints。")
        return

    pose = _capture_pose(joints)
    if not pose:
        cmds.warning("没有读取到任何旋转姿势。")
        return

    cmds.undoInfo(openChunk=True, chunkName="Codex record current pose to M")
    try:
        keyed = _key_pose(_driver_plug(), joints, pose, float(value))
        cmds.select(joints, replace=True)
        print("完成: 当前姿势已记录为 M=%s，写入 %d 个旋转通道。" % (value, keyed))
    finally:
        cmds.undoInfo(closeChunk=True)


def oneclick_current_fist(*_args):
    if not _ensure_driver():
        return
    joints = _target_joints()
    if not joints:
        cmds.warning("先加载这只手的手指 joints。")
        return

    fist_pose = _capture_pose(joints)
    if not fist_pose:
        cmds.warning("没有读取到当前拳头姿势。")
        return

    cmds.undoInfo(openChunk=True, chunkName="Codex oneclick current fist M")
    try:
        deleted = _clear_m_drivers_for_joints(joints)
        keyed0 = _key_pose(_driver_plug(), joints, _zero_pose(joints), 0.0)
        keyed5 = _key_pose(_driver_plug(), joints, fist_pose, MAX_M)
        cmds.setAttr(_driver_plug(), 0.0)
        cmds.select(STATE["driver"], replace=True)
        print("完成: M=0 为伸直，M=5 为刚才屏幕上的拳头。")
        print("关节数 %d / 删除旧曲线 %d / 写入通道 %d" % (len(joints), deleted, keyed0 + keyed5))
    finally:
        cmds.undoInfo(closeChunk=True)


def manual_rebuild_hint(*_args):
    if not _ensure_driver():
        return
    joints = _target_joints()
    if not joints:
        cmds.warning("先加载这只手的 joints。")
        return

    cmds.undoInfo(openChunk=True, chunkName="Codex prepare manual M rebuild")
    try:
        deleted = _clear_m_drivers_for_joints(joints)
        cmds.setAttr(_driver_plug(), 0.0)
        cmds.select(joints, replace=True)
        print("准备好了: 已清掉当前加载 joints 的旧 M 驱动 %d 条。" % deleted)
        print("流程: 先摆伸直 -> 点 记录 M=0；再摆拳头 -> 点 记录 M=5。")
    finally:
        cmds.undoInfo(closeChunk=True)


def show_ui():
    for win in OLD_WINDOWS + (WIN,):
        if cmds.window(win, exists=True):
            cmds.deleteUI(win)

    _resolve_driver()
    _ensure_driver()

    cmds.window(WIN, title="Codex 手指 M 合并工具", sizeable=False)
    cmds.columnLayout(adjustableColumn=True, rowSpacing=7, columnAttach=("both", 8))
    cmds.text(label="一个窗口处理 M。先加载控制圈和这只手的 joints，再按按钮。")
    cmds.text("codex_m_driver_label", label="M 控制器: 未加载")
    cmds.button(label="加载当前选择为 M 控制器", command=load_driver)
    cmds.text("codex_m_joints_label", label="关节数: 0")
    cmds.button(label="加载当前选择及子级里的 joints", command=load_selected_joints)
    cmds.button(label="自动加载 EW/ew 手指 joints", command=auto_load_fallback_joints)
    cmds.button(label="兜底: 扫描全场景 joints", command=scan_scene_joints)
    cmds.separator(height=8, style="in")
    cmds.button(label="准备手动重做: 清掉已加载 joints 的旧 M 驱动", command=manual_rebuild_hint)
    cmds.button(label="伸直已加载 joints: 旋转归零", command=straighten_loaded_joints)
    cmds.button(label="设 M=0", command=lambda *_: set_m(0))
    cmds.button(label="记录当前姿势为 M=0", command=lambda *_: record_current_pose(0))
    cmds.button(label="设 M=5", command=lambda *_: set_m(5))
    cmds.button(label="记录当前姿势为 M=5", command=lambda *_: record_current_pose(5))
    cmds.separator(height=8, style="in")
    cmds.button(label="一键: 当前拳头=M5，旋转归零=M0", command=oneclick_current_fist)
    cmds.button(label="只清掉已加载 joints 的旧 M 驱动", command=clear_loaded_drivers)
    cmds.text(label="不做镜像。弄错直接 Ctrl+Z。")
    cmds.showWindow(WIN)
    _refresh()


show_ui()
