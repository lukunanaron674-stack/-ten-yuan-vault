from __future__ import annotations

import maya.cmds as cmds


ATTR = "M"
FALLBACK_DRIVER = "nurbsCircle4"


def _pick_driver() -> str | None:
    sel = cmds.ls(selection=True, long=False) or []
    for node in sel:
        if cmds.objExists(f"{node}.{ATTR}"):
            return node
    if cmds.objExists(f"{FALLBACK_DRIVER}.{ATTR}"):
        return FALLBACK_DRIVER
    cmds.warning("找不到带 M 属性的控制器。请先选手腕控制圈。")
    return None


def reset_m_driven_keys() -> None:
    driver = _pick_driver()
    if not driver:
        return

    plug = f"{driver}.{ATTR}"
    curves = cmds.listConnections(plug, source=False, destination=True, type="animCurve") or []
    curves = sorted(set(curves))

    cmds.undoInfo(openChunk=True, chunkName="Codex reset M driven keys")
    try:
        try:
            cmds.setAttr(plug, lock=False)
            cmds.setAttr(plug, 0)
        except Exception:
            pass

        deleted = 0
        for curve in curves:
            if cmds.objExists(curve):
                try:
                    cmds.delete(curve)
                    deleted += 1
                except Exception as exc:
                    cmds.warning(f"删除 {curve} 失败: {exc}")

        # Keep M as a clean 0..10 control for rebuilding.
        try:
            cmds.addAttr(plug, edit=True, min=0, max=10)
        except Exception:
            pass
        cmds.setAttr(plug, 0)
        cmds.setAttr(plug, keyable=True, channelBox=True)
        cmds.select(driver, replace=True)
        print(f"完成：已重置 {plug}，删除旧驱动曲线 {deleted} 条。")
        print("现在可以重新接：建议先用 rotateZ -15 或 -20，不要再直接 -35。")
    finally:
        cmds.undoInfo(closeChunk=True)


reset_m_driven_keys()
