from __future__ import annotations

import maya.cmds as cmds


OLD_DRIVER = "nurbsCircle4"
ATTR = "M"


def _plug(node: str) -> str:
    return f"{node}.{ATTR}"


def _ensure_m_attr(node: str) -> None:
    plug = _plug(node)
    if not cmds.objExists(plug):
        cmds.addAttr(node, ln=ATTR, at="double", min=0, max=10, dv=0, k=True)
    else:
        try:
            cmds.addAttr(plug, edit=True, min=0, max=10)
        except Exception:
            pass
    cmds.setAttr(plug, lock=False, keyable=True, channelBox=True)


def move_m_to_selected_control() -> None:
    sel = cmds.ls(selection=True, long=False) or []
    if not sel:
        cmds.warning("先选中你想作为“手腕 M 控制器”的那个控制圈，再运行这个脚本。")
        return

    new_driver = sel[0]
    if cmds.nodeType(new_driver) == "joint":
        cmds.warning("你现在选的是 joint。请选手腕/手掌附近的控制圈，不要选骨骼。")
        return

    if not cmds.objExists(new_driver):
        cmds.warning(f"找不到选择对象: {new_driver}")
        return

    cmds.undoInfo(openChunk=True, chunkName="Codex move M driver to selected control")
    try:
        _ensure_m_attr(new_driver)
        new_plug = _plug(new_driver)

        old_plug = _plug(OLD_DRIVER)
        dests = []
        if cmds.objExists(old_plug):
            dests = cmds.listConnections(old_plug, source=False, destination=True, plugs=True) or []

        moved = 0
        for dest in sorted(set(dests)):
            try:
                cmds.connectAttr(new_plug, dest, force=True)
                moved += 1
            except Exception as exc:
                cmds.warning(f"没能转移连接 {dest}: {exc}")

        # Preserve the current slider value if possible.
        value = 0.0
        if cmds.objExists(old_plug):
            try:
                value = float(cmds.getAttr(old_plug))
            except Exception:
                pass
        cmds.setAttr(new_plug, value)
        cmds.select(new_driver, replace=True)

        print(f"完成：M 控制器改为 {new_driver}.{ATTR}")
        print(f"转移连接数量: {moved}")
        print("以后只调这个控制器的 M。那个测试弹窗只是施工工具，不是最终控制器。")
    finally:
        cmds.undoInfo(closeChunk=True)


move_m_to_selected_control()
