from __future__ import annotations

import re
from pathlib import Path

import maya.cmds as cmds


ORIGINAL_MA = Path(r"C:\Users\19308\Desktop\mood2.ma")
DRIVER = "nurbsCircle4"
ATTR = "M"
WIN = "codex_mood2_straighten_from_original"

DEFAULT_PASTED_FINGER_JOINTS = [
    "pasted__joint9",
    "pasted__joint10",
    "pasted__joint18",
    "pasted__joint19",
    "pasted__joint20",
    "pasted__joint14",
    "pasted__joint15",
    "pasted__joint16",
    "pasted__joint17",
    "pasted__joint21",
    "pasted__joint22",
    "pasted__joint23",
    "pasted__joint24",
]


def _parse_original_rotations() -> dict[str, tuple[float, float, float]]:
    if not ORIGINAL_MA.exists():
        cmds.warning(f"找不到原始文件: {ORIGINAL_MA}")
        return {}

    rotations: dict[str, tuple[float, float, float]] = {}
    current: str | None = None
    create_re = re.compile(r'createNode\s+joint\s+-n\s+"([^"]+)"')
    rotate_re = re.compile(
        r'setAttr\s+"\.r"\s+-type\s+"double3"\s+([-+0-9.eE]+)\s+([-+0-9.eE]+)\s+([-+0-9.eE]+)'
    )

    for line in ORIGINAL_MA.read_text(encoding="utf-8", errors="ignore").splitlines():
        match = create_re.search(line)
        if match:
            current = match.group(1)
            rotations.setdefault(current, (0.0, 0.0, 0.0))
            continue
        if current:
            r = rotate_re.search(line)
            if r:
                rotations[current] = (float(r.group(1)), float(r.group(2)), float(r.group(3)))
    return rotations


def _selected_joints() -> list[str]:
    return [
        node
        for node in (cmds.ls(selection=True, long=False) or [])
        if cmds.objExists(node) and cmds.nodeType(node) == "joint"
    ]


def _target_joints(use_selection: bool) -> list[str]:
    joints = _selected_joints() if use_selection else []
    if not joints:
        joints = [joint for joint in DEFAULT_PASTED_FINGER_JOINTS if cmds.objExists(joint)]
    return joints


def _delete_incoming_anim_curve(plug: str) -> None:
    sources = cmds.listConnections(plug, source=True, destination=False, plugs=False) or []
    for src in sources:
        if cmds.objExists(src) and cmds.nodeType(src).startswith("animCurve"):
            try:
                cmds.delete(src)
            except Exception:
                pass


def _ensure_driver() -> str | None:
    if not cmds.objExists(DRIVER):
        cmds.warning(f"找不到 {DRIVER}，请选/确认手腕控制器。")
        return None
    plug = f"{DRIVER}.{ATTR}"
    if not cmds.objExists(plug):
        cmds.addAttr(DRIVER, ln=ATTR, at="double", min=0, max=5, dv=0, k=True)
    else:
        try:
            cmds.addAttr(plug, edit=True, min=0, max=5)
        except Exception:
            pass
    cmds.setAttr(plug, lock=False, keyable=True, channelBox=True)
    return plug


def straighten(use_selection: bool = True, record_m0: bool = False) -> None:
    rotations = _parse_original_rotations()
    joints = _target_joints(use_selection)
    if not joints:
        cmds.warning("没有找到要伸直的手指 joints。可以先在大纲里多选手指 joints。")
        return

    driver_plug = _ensure_driver() if record_m0 else None

    cmds.undoInfo(openChunk=True, chunkName="Codex straighten hand from original")
    try:
        if driver_plug:
            cmds.setAttr(driver_plug, 0)

        changed = 0
        for joint in joints:
            rx, ry, rz = rotations.get(joint, (0.0, 0.0, 0.0))
            for attr, value in [("rx", rx), ("ry", ry), ("rz", rz)]:
                plug = f"{joint}.{attr}"
                if not cmds.objExists(plug):
                    continue
                _delete_incoming_anim_curve(plug)
                try:
                    cmds.setAttr(plug, lock=False, keyable=True, channelBox=True)
                    cmds.setAttr(plug, value)
                    if driver_plug:
                        cmds.setDrivenKeyframe(plug, cd=driver_plug)
                    changed += 1
                except Exception as exc:
                    cmds.warning(f"伸直 {plug} 失败: {exc}")

        cmds.select(joints, replace=True)
        if record_m0:
            print(f"完成：已伸直 {len(joints)} 个 joint，并记录为 {DRIVER}.{ATTR}=0。")
        else:
            print(f"完成：已伸直 {len(joints)} 个 joint，修改旋转通道 {changed} 个。")
    finally:
        cmds.undoInfo(closeChunk=True)


def show_ui() -> None:
    if cmds.window(WIN, exists=True):
        cmds.deleteUI(WIN)
    cmds.window(WIN, title="Codex 恢复手指伸直", sizeable=False)
    cmds.columnLayout(adjustableColumn=True, rowSpacing=8, columnAttach=("both", 8))
    cmds.text(label="从桌面原始 mood2.ma 读取手指原始旋转，把当前拳头恢复伸直")
    cmds.button(label="伸直当前选择的 joints", command=lambda *_: straighten(True, False))
    cmds.button(label="伸直常用 pasted 手指 joints", command=lambda *_: straighten(False, False))
    cmds.separator(height=8, style="in")
    cmds.button(label="伸直并记录为 M=0", command=lambda *_: straighten(False, True))
    cmds.text(label="如果结果不对，直接 Ctrl+Z 撤销。")
    cmds.showWindow(WIN)


show_ui()
