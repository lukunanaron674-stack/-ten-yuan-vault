# Maya M Hand Tool Portable

这个文件夹是给另一台电脑的 Maya 用的便携版。

## 最常用：打开 M 手势工具

1. 把整个文件夹解压到任意位置，比如桌面。
2. 打开 Maya。
3. 打开 `窗口 > 常规编辑器 > 脚本编辑器`。
4. 切到 `Python` 标签。
5. 运行下面这句，把路径改成你解压后的实际路径：

```python
exec(open(r"C:\你的路径\Maya_M_Tool_Portable\mood2_M_hand_tool_loader.py", encoding="utf-8").read())
```

如果文件夹就在桌面，路径大概像这样：

```python
exec(open(r"C:\Users\你的用户名\Desktop\Maya_M_Tool_Portable\mood2_M_hand_tool_loader.py", encoding="utf-8").read())
```

## 使用顺序

1. 选中手腕/手指的 `M` 控制圈。
2. 点 `加载当前选择为 M 控制器`。
3. 选中要记录的手指 joints，或者选 root joint 后点 `加载当前选择及子级里的 joints`。
4. 点 `先点我：清空旧 M 驱动，进入手动摆姿势`。
5. `设 M=0`，把手摆成伸直，点 `记录当前姿势为 M=0`。
6. `设 M=5`，把手摆成握拳，点 `记录当前姿势为 M=5`。

之后改控制器上的 `M` 数值，就会在伸直和握拳之间过渡。

## 注意

- 不建议在已经弄乱的场景里继续试镜像，先另存一份再操作。
- 这个工具主要是给 `mood2.ma` 这种手指 joint 命名结构使用的。
- 如果另一台电脑打不开，优先确认是在 Maya 的 `Python` 标签运行，不是 `MEL` 标签。
