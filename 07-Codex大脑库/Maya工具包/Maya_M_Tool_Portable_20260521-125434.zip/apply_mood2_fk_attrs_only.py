from __future__ import annotations

import argparse
import os


def _init_maya():
    try:
        import maya.standalone  # type: ignore

        maya.standalone.initialize(name="python")
    except Exception as exc:
        if "Already initialized" not in str(exc):
            raise
    import maya.cmds as cmds  # type: ignore

    return cmds


def _add_float_attr(cmds, node: str, attr: str, default: float, minimum: float, maximum: float) -> None:
    if not cmds.objExists(node):
        return
    plug = f"{node}.{attr}"
    if not cmds.objExists(plug):
        cmds.addAttr(node, ln=attr, at="double", min=minimum, max=maximum, dv=default, k=True)
    cmds.setAttr(plug, default)
    cmds.setAttr(plug, keyable=True, channelBox=True)


def _lock_non_rotation(cmds, node: str) -> None:
    if not cmds.objExists(node):
        return
    for attr in ["tx", "ty", "tz", "sx", "sy", "sz", "v"]:
        plug = f"{node}.{attr}"
        if cmds.objExists(plug):
            try:
                cmds.setAttr(plug, lock=True, keyable=False, channelBox=False)
            except Exception:
                pass
    for attr in ["rx", "ry", "rz"]:
        plug = f"{node}.{attr}"
        if cmds.objExists(plug):
            try:
                cmds.setAttr(plug, lock=False, keyable=True, channelBox=True)
            except Exception:
                pass


def apply_setup(source: str, output: str) -> None:
    cmds = _init_maya()
    source = os.path.abspath(source)
    output = os.path.abspath(output)
    cmds.file(source, open=True, force=True, ignoreVersion=True, prompt=False)

    # These two controls are the wrist-like controls visible in the tutorial-style scene.
    for node in ["nurbsCircle4", "ew1"]:
        _add_float_attr(cmds, node, "M", 0.0, -5.0, 5.0)
        _add_float_attr(cmds, node, "curl", 0.0, -10.0, 10.0)

    # Keep this pass non-destructive: channel cleanup only, no new constraints or driven keys.
    for node in ["nurbsCircle4", "ew1"]:
        _lock_non_rotation(cmds, node)

    note = "codex_fk_attrs_only_NOTE"
    if not cmds.objExists(note):
        cmds.createNode("network", name=note)
    if not cmds.objExists(f"{note}.note"):
        cmds.addAttr(note, ln="note", dt="string")
    cmds.setAttr(
        f"{note}.note",
        "Codex added only wrist custom attributes M/curl and locked non-rotation channels. No joints were driven.",
        type="string",
    )

    cmds.file(rename=output)
    cmds.file(save=True, type="mayaAscii", force=True)
    print(f"Wrote: {output}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Add non-destructive hand-control attributes to mood2.ma.")
    parser.add_argument("--source", default=r"C:\Users\19308\Desktop\mood2.ma")
    parser.add_argument("--output", default=r"C:\Users\19308\Desktop\mood2_codex_attrs_only.ma")
    args = parser.parse_args()
    apply_setup(args.source, args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
