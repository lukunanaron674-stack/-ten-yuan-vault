#!/bin/bash
# 阿光 · 定时触发标记写入
# 每15分钟写入一个触发标记，由主agent HEARTBEAT检测并spawn阿光
MARKER_DIR="/workspace/三元宇宙/agents/阿光/.trigger"
mkdir -p "$MARKER_DIR"
date +%Y%m%d%H%M > "$MARKER_DIR/last_trigger"
