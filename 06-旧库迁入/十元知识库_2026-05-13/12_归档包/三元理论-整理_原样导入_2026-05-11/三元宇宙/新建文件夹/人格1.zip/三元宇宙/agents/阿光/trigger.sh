#!/bin/bash
# 阿光 · 触发脚本
# 由cron每15分钟调用一次，spawn阿光子代理执行扫描

AGENT_DIR="/workspace/三元宇宙/agents/阿光"
TASK_FILE="$AGENT_DIR/AGENT_TASK.md"
LOG_DIR="/workspace/memory/阿光-执行日志"
TIMESTAMP=$(date +%Y-%m-%d-%H%M)

mkdir -p "$LOG_DIR"

# 生成触发日志（说明这次触发发生了什么）
LOG_ENTRY="$LOG_DIR/阿光-触发-$TIMESTAMP.md"

{
  echo "# 阿光触发日志"
  echo ""
  echo "**触发时间：** $(date -u +%Y-%m-%d\ %H:%M UTC)"
  echo ""
  echo "## 本次触发动作"
  echo ""
  echo "sessions_spawn 调用参数："
  echo "- task: 读取 $TASK_FILE 并按内容执行"
  echo "- runtime: subagent"
  echo "- mode: run"
  echo "- cwd: /workspace"
  echo ""
  echo "## 扫描目标"
  echo "- /workspace/memory/凛-理论迭代/"
  echo "- /workspace/三元宇宙/tasks/TASK-*.md"
  echo "- /workspace/三元宇宙/三元理论版本记录.md"
  echo ""
  echo "## 执行状态"
  echo "- 触发脚本执行完成"
  echo "- 等待子agent响应..."
} > "$LOG_ENTRY"

echo "阿光触发完成: $LOG_ENTRY"
